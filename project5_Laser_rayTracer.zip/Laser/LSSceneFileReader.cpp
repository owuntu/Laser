//
//  LSSceneFileReader.cpp
//  Laser
//
//  Created by Ou Yuntao on 12-3-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#include "LSSceneFileReader.h"

using namespace std;
bool sceneFileReader(FILE* sceneFile, LSScene &scene)
{
    
    //Identify the scene file
    char c=' ';
    string s = "";
    c = fgetc(sceneFile);
    while (c != '\n' && c!= '\r') {
        s += c;
        c = fgetc(sceneFile);
    }
    if (!(s=="U5")) {
        printf("This is not a .urt scenefile");
        return 0;
    }
    
    scene.numOfLight=0;
    //FILE* sourceFile;   //.raw or .obj
    list<LSPrimitive*>::iterator iterObj;
    LSPrimitive* tempPrim;
    LSLight* testLight;
    
    //Get the raster width and height
    s = "";
    c = fgetc(sceneFile);
    while (c != '\n' && c!= '\r') {
        s += c;
        c = fgetc(sceneFile);
    }
    char* cstr;
    cstr = new char[s.size()+1];
    strcpy(cstr, s.c_str());
    char* tempEnd;
    char* tempEnd2;
    scene.rasterWidth = strtof(cstr, &tempEnd);
    scene.rasterHeight = strtof(tempEnd, NULL);
    scene.raster.setWidth(scene.rasterWidth);
    scene.raster.setHeight(scene.rasterHeight);
    scene.raster.newRaster();
    scene.raster.clear(LSColorFloat_Dark);
    delete cstr;
    //printf("width=%u, height=%u\n",rasterWidth, rasterHeight);
    s = "";
    c = fgetc(sceneFile);
    
    //Get camera information
    int lineCount = 0;
    while (lineCount<4) {
        s += c;
        c = fgetc(sceneFile);
        if (c == '\n' || c== '\r') {
            lineCount++;
        }
    }
    //ungetc(c, sceneFile);
    cstr = new char[s.size()+1];
    strcpy(cstr, s.c_str());
    scene.camera.setEyePoint(strtof(cstr, &tempEnd), strtof(tempEnd, &tempEnd2), strtof(tempEnd2, &tempEnd));
    scene.camera.setLookSpot(strtof(tempEnd, &tempEnd2), strtof(tempEnd2, &tempEnd), strtof(tempEnd, &tempEnd2));
    scene.camera.setUpVector(strtof(tempEnd2, &tempEnd), strtof(tempEnd, &tempEnd2), strtof(tempEnd2, &tempEnd));
    scene.camera.fieldOfViewAngleY = strtof(tempEnd, &tempEnd2);
    scene.camera.aspectRatio = strtof(tempEnd2, &tempEnd);
    delete cstr;
    
    s="";
    c=fgetc(sceneFile);
    while (c != '\n' && c!=EOF  && c!= '\r') {
        s += c;
        c = fgetc(sceneFile);
    }
    cstr = new char[s.size()+1];
    strcpy(cstr, s.c_str());
    scene.ambient.r = strtof(cstr, &tempEnd);
    scene.ambient.g = strtof(tempEnd, &tempEnd2);
    scene.ambient.b = strtof(tempEnd2, NULL);
    scene.ambient.a = 1.0f;
    delete cstr;

    
    //Get primitive
    while (c != EOF){
        s = "";
        c = fgetc(sceneFile);
        list<LSLight>::iterator iterTempL;
        switch (c) {
            //Sphere
            case 's':
                c=fgetc(sceneFile);
                while (c != '\n' && c!=EOF && c!= '\r') {
                    s += c;
                    c = fgetc(sceneFile);
                }
                cstr = new char[s.size()+1];
                strcpy(cstr, s.c_str());
                tempPrim = new LSSphere();
                ((LSSphere*)tempPrim)->setPrimitive(strtof(cstr, &tempEnd),     //x
                                                    strtof(tempEnd, &tempEnd2), //y
                                                    strtof(tempEnd2, &tempEnd), //z
                                                    strtof(tempEnd, &tempEnd2), //radius
                                                    strtof(tempEnd2, &tempEnd), //red
                                                    strtof(tempEnd, &tempEnd2), //green
                                                    strtof(tempEnd2, NULL));    //blue
                
                scene.objectList->push_back(tempPrim);
                delete cstr;
                break;

            // Get light information
            case 'l':
                c=fgetc(sceneFile);
                while (c != '\n' && c!=EOF && c!= '\r') {
                    s += c;
                    c = fgetc(sceneFile);
                }
                cstr = new char[s.size()+1];
                strcpy(cstr, s.c_str());
                testLight = new LSLight();
                testLight->myPosition->setX(strtof(cstr, &tempEnd));
                testLight->myPosition->setY(strtof(tempEnd, &tempEnd2));
                testLight->myPosition->setZ(strtof(tempEnd2, &tempEnd));
                testLight->myColor.r = strtof(tempEnd, &tempEnd2);
                testLight->myColor.g = strtof(tempEnd2, &tempEnd);
                testLight->myColor.b = strtof(tempEnd, NULL);
                testLight->myColor.a = 1.0f;
                testLight->myIndex = scene.numOfLight;
                scene.lightList.push_back(*testLight);
                //iterTempL = scene.lightList.end();
                //iterTempL--;
                //(*iterTempL).setLight(testLight.myColor, testLight.myPosition);
                scene.numOfLight++;
                delete cstr;
                break;
                
            // Plane
            case 'p':
                c=fgetc(sceneFile);
                while (c != '\n' && c!=EOF && c!= '\r') {
                    s += c;
                    c = fgetc(sceneFile);
                }
                cstr = new char[s.size()+1];
                strcpy(cstr, s.c_str());
                tempPrim = new LSPlane();
                ((LSPlane*)tempPrim)->setPrimitive(strtof(cstr, &tempEnd),     //x
                                                   strtof(tempEnd, &tempEnd2), //y
                                                   strtof(tempEnd2, &tempEnd), //z
                                                   strtof(tempEnd, &tempEnd2), //nx
                                                   strtof(tempEnd2, &tempEnd), //ny
                                                   strtof(tempEnd, &tempEnd2), //nz
                                                   colorFloatMake(255.0f, 
                                                                  strtof(tempEnd2, &tempEnd), //color.r
                                                                  strtof(tempEnd, &tempEnd2), //color.g
                                                                  strtof(tempEnd2, NULL)));   //color.b

                scene.objectList->push_back(tempPrim);
                delete cstr;
                break;
                
            case '#':
                c=getc(sceneFile);
                while (c != '\n' && c != EOF && c!= '\r') {
                    c=fgetc(sceneFile);
                }
                break;
            default:
                break;
        }
    }
    return 1;
}