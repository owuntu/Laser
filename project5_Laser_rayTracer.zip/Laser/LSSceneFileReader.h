//
//  LSSceneFileReader.h
//  Laser
//
//  Created by Ou Yuntao on 12-3-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef VikingGL_VKSceneFileReader_h
#define VikingGL_VKSceneFileReader_h

#include <string.h>
#include <stdio.h>
#include "LSScene.h"
#include "LSPrimitive.h"
#include "LSSphere.h"
#include "LSPlane.h"
#include <list.h>

bool sceneFileReader(FILE* sceneFile, LSScene &scene);

#endif
