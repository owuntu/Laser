//
//  LSPrimitive.cpp
//  Laser
//
//  Created by Ou Yuntao on 4/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "LSPrimitive.h"
#include "LSSphere.h"
#include "LSPlane.h"
#include <math.h>

PrimitiveType LSPrimitive::getMyType()
{
    return this->myType;
}

LSColorFloat LSPrimitive::getMyColor()
{
    return  this->_myColor;
}

void LSPrimitive::setPrimitive()
{
    
}

void LSPrimitive::intersect()
{
    
}

LSColorFloat LSPrimitive::getLightColor(LSScene *scene, LSRay ray, float t)
{
    std::list<LSLight>::iterator iterLight;
    std::list<LSPrimitive*>::iterator iterObj;
    LSColorFloat finalColor = LSColorFloat_Dark;
    
    int shadowCount = 0;
    for (iterLight = scene->lightList.begin(); iterLight != scene->lightList.end(); iterLight++) {
        //if ((*iterLight).myIndex == 1) {
         //   continue;
        //}
        LSVector intersectPoint = ray.calculateIntersectPoint(t);
        LSVector lightVec = *((*iterLight).myPosition) - intersectPoint;
        lightVec.normalise();
        
        bool shadow = false;
        LSRay ray2(intersectPoint, lightVec);
        std::list<LSPrimitive*>* objList = scene->objectList;
        for (iterObj = objList->begin(); iterObj != objList->end(); iterObj++) {
            if ((*iterObj) == this) {
                continue;
            }
            float near=NAN;
            float far=NAN;
            switch ((*iterObj)->getMyType()) {
                case SPHERE:
                    ((LSSphere*)(*iterObj))->intersect(ray2, &near, &far);
                    break;
                case PLANE:
                    ((LSPlane*)(*iterObj))->intersect(ray2, &near);
                    break;
                default:
                    break;
            }
            if (isnan(near) == false || isnan(far) == false) {
                shadow = true;
                //printf("light index=%i\n", (*iterLight).myIndex);
                break;
            }
        }
        
        if (shadow == true) {
            shadowCount++;
            continue;
        }
        LSVector normVec;
        switch (myType) {
            case SPHERE:
                normVec = ((LSSphere*)this)->calculateNorm(intersectPoint);
                break;
            case PLANE:
                normVec = ((LSPlane*)this)->getNorm();
                break;
            case TRIANGLE:
                break;
            default:
                break;
        }
        normVec.normalise();
        
        
        //LSVector viewVec = *(scene->camera.eyePoint) - intersectPoint;
        //viewVec.normalise();
        
        float l_dot_n = lightVec * normVec;
        float diffContr = fmaxf(l_dot_n, 0.0f);
        
        LSColorFloat diffuseI = (*iterLight).myColor * _myColor * diffContr;
        
        finalColor = finalColor + diffuseI;
        
    }
    LSColorFloat ambientI = _myColor * (scene->ambient);
    finalColor = finalColor + ambientI;
    colorNormalise(finalColor);
    
    return finalColor;
}

LSVector LSPrimitive::calculateNorm()
{
    LSVector tempVec(0.0f, 1.0f, 0.0f);
    return tempVec;
}