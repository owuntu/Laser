//
//  main.cpp
//  Laser
//
//  Created by Ou Yuntao on 4/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

//#include <iostream>
#include "image.h"
#include "LSVector.h"
#include "LSRaster.h"
#include "LSColor.h"
#include "LSRaster.h"
#include "LSSphere.h"
#include "LSSceneFileReader.h"
#include <math.h>
//using namespace std;

int main (int argc, const char * argv[])
{
    /*****This is only a test!***********
    LSVector v1(1.0, 2.0, -1.0);
    LSVector v2(3.0, 1.0, -2.0);
    LSVector vAdd = v1 + v2;
    LSVector vSubtract = v1-v2;
    float vDotProduct = v1 * v2;
    LSVector vCrossProduct = crossProduct(&v1, &v2);
    
    cout<<"add result=("<<vAdd.getX()<<", "<<vAdd.getY()<<", "<<vAdd.getZ()<<")"<<endl;
    cout<<"Subtract result=("<<vSubtract.getX()<<", "<<vSubtract.getY()<<", "<<vSubtract.getZ()<<")"<<endl;
    cout<<"Dot product result="<<vDotProduct<<endl;
    cout<<"cross product result=("<<vCrossProduct.getX()<<", "<<vCrossProduct.getY()<<", "<<vCrossProduct.getZ()<<")"<<endl;
    v2 = v1;
    cout<<"v2: ("<<v2.getX()<<", "<<v2.getY()<<", "<<v2.getZ()<<")"<<endl;
    v1 *= 2;
    cout<<"v1 change: ("<<v1.getX()<<", "<<v1.getY()<<", "<<v1.getZ()<<")"<<endl;
    cout<<"v2 after v1 change: ("<<v2.getX()<<", "<<v2.getY()<<", "<<v2.getZ()<<")"<<endl;
    /************/
    
    /*********This is the practice of ray tracing!****************
    LSRaster raster(800, 600);
    raster.clear(LSColorFloat_White);
    LSSphere sphere(LSVector(0.0f, 0.0f, -10.0f), 2.0f, LSColorFloat_Blue);
    LSSphere sphere1(LSVector(6.0f, 4.0f, -10.0f), 1.5f, LSColorFloat_Green);
    LSSphere sphere2(LSVector(-6.0f, -2.0f, -10.0f), 2.5f, LSColorFloat_Red);
    
    int numOfSphere = 3;
    LSSphere* sphereList = new LSSphere[3];
    sphereList[0] = sphere;
    sphereList[1] = sphere1;
    sphereList[2] = sphere2;
    
    LSVector eye(0.0f, 0.0f, 0.0f);
    LSVector screenCenter(0.0f, 0.0f, -1.0f);
    LSVector screenU(1.0f, 0.0f, 0.0f);
    LSVector screenV(0.0f, 1.0f, 0.0f);
    for (int x = 0; x<raster.getWidth(); x++) {
        for (int y=0; y<raster.getHeight(); y++) {
            LSVector rayOrigin = eye;
            LSVector u;
            LSVector v;
            if (raster.getWidth() > raster.getHeight()) {
                u = screenU * ((float)x / (float)raster.getWidth() * 2.0f - 1.0f) 
                    * ((float)raster.getWidth() / (float)raster.getHeight());
                v = screenV * ((float)y / (float)raster.getHeight() * 2.0f - 1.0f);
            }else{
                u = screenU * ((float)x / (float)raster.getWidth() * 2.0f - 1.0f);
                v = screenV * ((float)y / (float)raster.getHeight() * 2.0f - 1.0f) 
                    * ((float)raster.getHeight() / (float)raster.getWidth());
            }
            
            LSVector rayDirection = screenCenter - eye + u + v;
            
            LSRay ray(rayOrigin, rayDirection, LSColorFloat_White);
            float near = NAN;
            float far = NAN;
            for (int i=0; i<numOfSphere; i++) {
                sphereList[i].intersect(ray, &near, &far);
                if (isnan(near) == false) {
                    raster.pixels[x + y*raster.getWidth()] = drawARGBColorFromFloatColor(sphereList[i]._myColor);
                }
            }
        }
    }
    
    LSRaster raster2(80, 60);
    for (int x = 0; x<raster.getWidth(); x++) {
        for (int y=0; y<raster.getHeight(); y++) {
            if (x<20) {
                raster2.pixels[x+y*raster2.getWidth()] = drawARGBColorFromFloatColor(LSColorFloat_Red);
            }
        }
    }
    
    CORasterSaveToBMP(&raster, "image.bmp");
    CORasterSaveToBMP(&raster2, "image2.bmp");
    /**********************/
    
    //Scene file reader
    FILE* sceneFile = fopen("scene.urt", "r");
    if (sceneFile == NULL) {
        printf("Error. Could not open scene file.\n");
        return 1;
    }
    LSScene scene;
    scene.objectList = new list<LSPrimitive*>;
    std::list<LSPrimitive*>* primList = scene.objectList;
    sceneFileReader(sceneFile, scene);
    
    /******this is only a check!*******
    std::list<LSLight>::iterator iterLight;
    for (iterLight = scene.lightList.begin(); iterLight != scene.lightList.end(); iterLight++) {
        printf("l[%i] pos=%f, %f, %f\n", (*iterLight).myIndex, (*iterLight).myPosition->getX(), (*iterLight).myPosition->getY(), (*iterLight).myPosition->getZ());
    }
    *******/
    
    scene.camera.updateVec();
    LSVector eye = *(scene.camera.eyePoint);
    LSVector screenCenter = eye 
        + (*(scene.camera.lookVec) * (1.0f/tanf(scene.camera.aspectRatio/2.0f)));
    LSVector screenU = *(scene.camera.rightVec);
    LSVector screenV =  *(scene.camera.upVector);
    int rasterWidth = scene.raster.getWidth();
    int rasterHeight = scene.raster.getHeight();
    for (int x = 0; x<rasterWidth; x++) {
        for (int y=0; y<rasterHeight; y++) {
            LSVector rayOrigin = eye;
            LSVector u;
            LSVector v;
            if (rasterWidth > rasterHeight) {
                u = screenU * ((float)x / (float)rasterWidth * 2.0f - 1.0f) 
                * ((float)rasterWidth / (float)rasterHeight);
                v = screenV * ((float)y / (float)rasterHeight * 2.0f - 1.0f);
            }else{
                u = screenU * ((float)x / (float)rasterWidth * 2.0f - 1.0f);
                v = screenV * ((float)y / (float)rasterHeight * 2.0f - 1.0f) 
                * ((float)rasterHeight / (float)rasterWidth);
            }
            
            LSVector rayDirection = screenCenter - eye + u + v;
            
            LSRay ray(rayOrigin, rayDirection);
            float near = NAN;
            float far = NAN;
            for (list<LSPrimitive*>::iterator iterPr=primList->begin(); iterPr != primList->end(); iterPr++) {
                
                switch ((*iterPr)->getMyType()) {
                    case SPHERE:
                        ((LSSphere*)(*iterPr))->intersect(ray, &near, &far);
                        break;
                    case PLANE:
                        ((LSPlane*)(*iterPr))->intersect(ray, &near);
                        break;
                    default:
                        break;
                }
                if (isnan(near) == false) {
                    scene.raster.pixels[x + y*rasterWidth] = drawARGBColorFromFloatColor((*iterPr)->getLightColor(&scene, ray, near));
                }

            }
        }
    }
    
    CORasterSaveToBMP(&(scene.raster), "myImage.bmp");
    CORasterSaveToPPM(&(scene.raster), "myImage.ppm");
    
    fclose(sceneFile);
    return 0;
}

