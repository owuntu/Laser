//
//  LSPrimitive.cpp
//  Laser
//
//  Created by Ou Yuntao on 4/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include "LSPrimitive.h"
#include "LSSphere.h"
#include "LSPlane.h"
#include "LSTriangle.h"
#include <math.h>

PrimitiveType LSPrimitive::getMyType()
{
    return this->_myType;
}

LSColorFloat LSPrimitive::getMyColor()
{
    return  this->_myColor;
}

void LSPrimitive::setPrimitive()
{
    
}

void LSPrimitive::intersect()
{
    
}

LSColorFloat LSPrimitive::getLightColor(LSScene *scene, LSRay ray, float t)
{
    std::list<LSLight>::iterator iterLight;
    std::list<LSPrimitive*>::iterator iterObj;
    LSColorFloat finalColor = LSColorFloat_Dark;
    
    int shadowCount = 0;
    for (iterLight = scene->lightList.begin(); iterLight != scene->lightList.end(); iterLight++) {
        
        LSVector* intersectPoint = ray.calculateIntersectPoint(t);
        LSVector lightVec = *((*iterLight).myPosition) - *intersectPoint;
        lightVec.normalise();
        
        //calculate shadow
        bool shadow = false;
        LSRay ray2(*intersectPoint, lightVec);
        std::list<LSPrimitive*>* objList = scene->objectList;
        for (iterObj = objList->begin(); iterObj != objList->end(); iterObj++) {
            if (this->reflection == true) {
                break;
            }
            if ((*iterObj) == this) {
                continue;
            }
            float near=NAN;
            float far=NAN;
            switch ((*iterObj)->getMyType()) {
                case SPHERE:
                    ((LSSphere*)(*iterObj))->intersect(ray2, &near, &far);
                    break;
                case TRIANGLE:
                    ((LSTriangle*)(*iterObj))->intersect(ray2, &near);
                    break;
                case PLANE:
                    ((LSPlane*)(*iterObj))->intersect(ray2, &near);
                    break;
                default:
                    break;
            }
            if (isnan(near) == false || isnan(far) == false) {
                shadow = true;
                //printf("light index=%i\n", (*iterLight).myIndex);
                break;
            }
        }
        
        if (shadow == true) {
            shadowCount++;
            continue;
        }
        LSVector normVec;
        switch (_myType) {
            case SPHERE:
                normVec = ((LSSphere*)this)->calculateNorm(*intersectPoint);
                break;
            case TRIANGLE:
            case PLANE:
                normVec = ((LSPlane*)this)->getNorm();
                break;
                break;
            default:
                break;
        }
        normVec.normalise();
        
        float l_dot_n = lightVec * normVec;
        float diffContr = fmaxf(l_dot_n, 0.0f);
        //Diffuse lighting;
        LSColorFloat diffuseI = (*iterLight).myColor * _myColor * diffContr;
        
        //I am tring to do reflection
        LSVector viewVec = *(scene->camera.eyePoint) - *intersectPoint;
        viewVec.normalise();
        float v_dot_n = viewVec * normVec;
        if (_myType == SPHERE && v_dot_n > 0.0f) {
            LSVector reflectVec = normVec*(2.0*v_dot_n) - viewVec;
            LSRay reflectRay(*intersectPoint, reflectVec);
            for (iterObj = objList->begin(); iterObj != objList->end(); iterObj++) {
                if ((*iterObj) == this || this->reflection == false) {
                    continue;
                }
                diffuseI = LSColorFloat_Dark;
                float near=NAN;
                float far=NAN;
                switch ((*iterObj)->getMyType()) {
                    case SPHERE:
                        ((LSSphere*)(*iterObj))->intersect(reflectRay, &near, &far);
                        break;
                    case PLANE:
                        ((LSPlane*)(*iterObj))->intersect(reflectRay, &near);
                        break;
                    default:
                        break;
                }
                if (isnan(near) == false) {
                    LSColorFloat tempColor = (*iterObj)->getLightColor(scene, reflectRay, near);
                    finalColor = finalColor + (_myColor * tempColor);
                }
            }
        }
        
        
        finalColor = finalColor + diffuseI;
        
    }
    LSColorFloat ambientI = _myColor * (scene->ambient);
    if (this->reflection == true) {
        ambientI = LSColorFloat_Dark;
    }
    finalColor = finalColor + ambientI;
    colorNormalise(finalColor);
    
    return finalColor;
}

LSVector LSPrimitive::calculateNorm()
{
    LSVector tempVec(0.0f, 1.0f, 0.0f);
    return tempVec;
}

void LSPrimitive::setMyColor(LSColorFloat color)
{
    _myColor = color;
}