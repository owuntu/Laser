//
//  main.cpp
//  Laser
//
//  Created by Ou Yuntao on 4/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

//==============================I am the fantastic seperated line==========================//
/*****************************TO DO: Solve the problem of triangles************************/
//======================================END================================================//


#include "image.h"
#include "LSVector.h"
#include "LSRaster.h"
#include "LSColor.h"
#include "LSRaster.h"
#include "LSSphere.h"
#include "LSSceneFileReader.h"
#include <math.h>
#include <time.h>

int main (int argc, const char * argv[])
{
    time_t start, end;
    double timeCost = 0.0;
    time(&start);
    
    //Scene file reader
    FILE* sceneFile = fopen("scene.urt", "r");
    if (sceneFile == NULL) {
        printf("Error. Could not open scene file.\n");
        return 1;
    }
    LSScene scene;
    scene.objectList = new list<LSPrimitive*>;
    std::list<LSPrimitive*>* primList = scene.objectList;
    sceneFileReader(sceneFile, scene);
    
    scene.camera.updateVec();
    LSVector eye = *(scene.camera.eyePoint);
    //(scene.camera.lookVec)->normalise();
    LSVector screenCenter = eye 
        + (*(scene.camera.lookVec) * ((scene.camera.lookVec)->getMagnitude()/tanf(scene.camera.fieldOfViewAngleY/2.0f)));
    LSVector screenU = *(scene.camera.rightVec);
    LSVector screenV =  *(scene.camera.upVector);
    int rasterWidth = scene.raster.getWidth();
    int rasterHeight = scene.raster.getHeight();
    
    /*/add reflection on the last object
    std::list<LSPrimitive*>::iterator iterObj;
    iterObj = scene.objectList->end();
    iterObj--;
    (*iterObj)->reflection = true;
    (*iterObj)->setMyColor(LSColorFloat_White);
    /***/
    
    for (int x = 0; x<rasterWidth; x++) {
        for (int y=0; y<rasterHeight; y++) {
            LSVector rayOrigin = eye;
            LSVector u;
            LSVector v;
            if (rasterWidth > rasterHeight) {
                u = screenU * ((float)x / (float)rasterWidth * 2.0f - 1.0f) 
                    * ((float)rasterWidth / (float)rasterHeight);
                v = screenV * ((float)y / (float)rasterHeight * 2.0f - 1.0f);
            }else{
                u = screenU * ((float)x / (float)rasterWidth * 2.0f - 1.0f);
                v = screenV * ((float)y / (float)rasterHeight * 2.0f - 1.0f) 
                    * ((float)rasterHeight / (float)rasterWidth);
            }
            
            LSVector rayDirection = screenCenter - eye + u + v;
            
            LSRay ray(rayOrigin, rayDirection);
            float near = NAN;
            float far = NAN;
            for (list<LSPrimitive*>::iterator iterPr=primList->begin(); iterPr != primList->end(); iterPr++) {
                
                switch ((*iterPr)->getMyType()) {
                    case SPHERE:
                        ((LSSphere*)(*iterPr))->intersect(ray, &near, &far);
                        break;
                    case PLANE:
                        ((LSPlane*)(*iterPr))->intersect(ray, &near);
                        break;
                    case TRIANGLE:
                        ((LSTriangle*)(*iterPr))->intersect(ray, &near);
                        //((LSTriangle*)(*iterPr))->printInfo();
                        break;
                    default:
                        break;
                }
                if (isnan(near) == false) {
                    scene.raster.pixels[x + y*rasterWidth] = drawARGBColorFromFloatColor((*iterPr)->getLightColor(&scene, ray, near));
                }

            }
        }
    }
    
    CORasterSaveToBMP(&(scene.raster), "myImage.bmp");
    CORasterSaveToPPM(&(scene.raster), "myImage.ppm");
    
    fclose(sceneFile);
    
    time(&end);
    timeCost = difftime(end, start);
    printf("It took %.2f sec to run the whole program.\n", timeCost);
    return 0;
}

